DEFAULT_API_PREFIX = "/resource/"
OLD_API_PREFIX = "/api/views"
